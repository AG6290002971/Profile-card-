import { motion } from "framer-motion";

export default function ProfileCard({
  name,
  title,
  handle,
  status,
  contactText,
  avatarUrl,
  miniAvatarUrl,
  showUserInfo,
  enableTilt,
  enableMobileTilt,
  onContactClick,
}) {
  return (
    <motion.div
      className="bg-gray-900 text-white rounded-2xl shadow-xl p-6 max-w-sm w-full flex flex-col items-center space-y-4"
      whileHover={{ scale: enableTilt ? 1.05 : 1 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <img
        src={avatarUrl}
        alt={name}
        className="w-32 h-32 rounded-full object-cover border-4 border-purple-500 shadow-md"
      />
      {showUserInfo && (
        <div className="text-center">
          <h2 className="text-xl font-bold">{name}</h2>
          <p className="text-purple-400">{title}</p>
          <p className="text-gray-400">@{handle}</p>
        </div>
      )}
      <p className="text-gray-300 italic">"{status}"</p>
      <button
        onClick={onContactClick}
        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-xl font-semibold shadow-md"
      >
        {contactText}
      </button>
      <img
        src={miniAvatarUrl}
        alt="mini avatar"
        className="w-10 h-10 rounded-full border-2 border-purple-400 shadow-md mt-2"
      />
    </motion.div>
  );
}
