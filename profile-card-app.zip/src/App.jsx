import ProfileCard from "./ProfileCard";
import "./index.css";

export default function App() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-black">
      <ProfileCard
        name="Aditya Ghosh"
        title="Full stack developer"
        handle="_aditya.ghosh_629000"
        status="Chasing Happiness 🫰😌"
        contactText="Contact Me"
        avatarUrl="https://drive.google.com/uc?export=view&id=1zZDgpGLEHiJtz7hHI35UCETymhIS9Ukz"
        miniAvatarUrl="https://drive.google.com/uc?export=view&id=1zZDgpGLEHiJtz7hHI35UCETymhIS9Ukz"
        showUserInfo={true}
        enableTilt={true}
        enableMobileTilt={true}
        onContactClick={() =>
          window.open("https://instagram.com/_aditya.ghosh_629000", "_blank")
        }
      />
    </div>
  );
}
